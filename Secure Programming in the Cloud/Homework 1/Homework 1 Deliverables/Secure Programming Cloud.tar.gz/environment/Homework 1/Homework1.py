# File: Homework1.py
# Author: Ben Brandhorst
# Date: March 24th, 2020
# Purpose: SDEV400 Homework

from random import randrange
import logging
import boto3
import botocore
import time
from botocore.exceptions import ClientError

## Command line menu format source https://extr3metech.wordpress.com/2014/09/14/simple-text-menu-in-python/
def print_menu():       
    print (50 * '-' , 'MENU' , 50 * '-')
    print ("Welcome to Ben Brandhorst's SDEV400 Homework 1 Submission. Please select from the menu below.")
    print ('')
    print ('1. Create a S3 bucket with the name consisting of your firstname, lastname and a random 6- digit suffix.')
    print ('2. Upload File1.txt and File2.txt to benbrandhorst1 bucket.')
    print ('3. Delete Uploaded1.txt from benbrandhorst1.')
    print ('4. Delete an empty bucket from a list of buckets.')
    print ('5. Copy Uploaded2 from benbrandhorst1 to benbrandhorst2.')
    print ('6. Download Copied1.txt from benbrandhorst2.')
    print ('7. Exit the Program')
    print (107 * '-')

def bucket():
    # Creates the filename for the bucket using input for First name and Last name
    fname = input('Please enter your first name ')
    lname = input('Please enter your last name ')
    filename = ('')
    number = randrange(100000,999999,1)
    dash = ("-")
    filename += fname.lower()
    filename += lname.lower()
    filename += dash
    filename += str(number)
    
    # Create bucket used in menu selection 1
    try:
            s3_client = boto3.client('s3')
            s3_client.create_bucket(Bucket=filename)
            print('Created a bucket named '+str(filename) )
    except ClientError as e:
        logging.error(e)

def upload():
    # Uploads 2 text files to benbrandhorst1 and saves as Uploaded1.txt and Uploaded2.txt 
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file('/home/ec2-user/environment/File1.txt','benbrandhorst1', 'Uploaded1.txt')
        print ('File1.txt uploaded to a bucket named benbrandhorst1 and saved as Uploaded1.txt')
        response = s3_client.upload_file('/home/ec2-user/environment/File2.txt','benbrandhorst1', 'Uploaded2.txt')
        print ('File2.txt uploaded to a bucket named benbrandhorst1 and saved as Uploaded2.txt')
    except ClientError as e:
        logging.error(e)
        return False
    return True
    
def deleteFile():
   # Delete Uploaded1.txt from benbrandhorst1
    s3 = boto3.client('s3')
    try:
        s3.delete_object(Bucket='benbrandhorst1', Key='Uploaded1.txt')
        print ('Deleted Uploaded1.txt from bucket benbrandhorst1.')
    except ClientError as e:
        logging.error(e)
        return False
    return True
    
def deleteBucket():
    # Lists the buckets created
    s3 = boto3.client('s3')
    response = s3.list_buckets()
    buckets = [bucket['Name'] for bucket in response['Buckets']]
    print("Bucket list: %s" % buckets)
    # Deletes the empty bucket the user selects
    try: 
        bucketDelete = input("Please select the bucket to delete. ")
        print('Deleted bucket ' +str(bucketDelete))
        s3.delete_bucket(Bucket=bucketDelete)
    except ClientError as e:
        logging.error(e)
        return False
    return True

def copyObject():
    # Copies Uploaded2.txt from benbrandhorst1 bucket to benbrandhorst2 bucket and renames file Copied1.txt
    try:
        copy_source = { 'Bucket': 'benbrandhorst1', 'Key': 'Uploaded2.txt'}
        s3 = boto3.resource('s3')
        bucket = s3.Bucket('benbrandhorst2')
        bucket.copy(copy_source, 'Copied1.txt')
        print('Copied Uploaded2.txt from bucket benbrandhorst1 to bucket benbrandhorst2 and renamed the file Copied1.txt. ')
    except ClientError as e:
        logging.error(e)
        return False
    return True

def downloadFile():
    # Downloads Copied1.txt from benbrandhorst2 and saves as DownloadedFile.txt 
    s3 = boto3.resource('s3')
    try:
         s3.Bucket('benbrandhorst2').download_file('Copied1.txt', 'DownloadedFile.txt')
         print('Copied1.txt has been downloaded from bucket benbrandhorst2 and saved as DownloadedFile.txt')
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("The object does not exist.")
        else:
              raise

def displayTime(): 
    # Source for code https://www.tutorialspoint.com/python/python_date_time.htm
    # Displays local time
    localtime = time.asctime( time.localtime(time.time()) )
    print ('Program shut down at:', localtime)

# Loop for menu that runs until "Exit Program" is selected     
loop=True      
while loop:
    print_menu()
    choice = input('Enter your choice [1-7]: ')
    if choice==('1'):
        # Runs bucket() method to create a new bucket
        bucket()    
    elif choice==('2'):
        # Runs upload() method to upload objects
        upload()
    elif choice==('3'):
        # Runs deleteFile() method to delete files
        deleteFile()
    elif choice==('4'):
        # Runs deleteBucket() method to delete selected bucket
        deleteBucket()
    elif choice==('5'):
        # Runs copyObject() method to copy object from one bucket to another
        copyObject()
    elif choice==('6'):
        # Runs downloadFile() method to download file from bucket
        downloadFile()
    elif choice==('7'):
        # Exits program
        print("You have selected 'Exit Program'")
        displayTime()
        loop=False 
    else:
        # Any integer inputs other than values 1-7 returns this error
        input("Wrong option selection. Enter any key to try again.")
        